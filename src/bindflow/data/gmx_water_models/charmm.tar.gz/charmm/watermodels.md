# INFO

All the water models were taken from GROMACS force field charmm27 [share/top](https://gitlab.com/gromacs/gromacs/-/tree/main/share/top?ref_type=heads).
