# INFO

All the water models were taken from GROMACS force field oplsaa [share/top](https://gitlab.com/gromacs/gromacs/-/tree/main/share/top?ref_type=heads).
