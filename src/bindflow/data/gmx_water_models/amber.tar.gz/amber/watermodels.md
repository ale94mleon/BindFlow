# INFO

All the water models were taken from GROMACS force field amber99sb-ildn [share/top](https://gitlab.com/gromacs/gromacs/-/tree/main/share/top?ref_type=heads).
