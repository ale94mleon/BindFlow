# Rretrvieving data

The fiels are taking from:
[https://github.com/samplchallenges/SAMPL9/tree/main/host_guest/WP6]

```python
from toff import Parameterize
from rdkit import Chem

dict_to_work = {
        'conf': Chem.MolFromMolFile("WP6.sdf"),
        "ff": {
            "type": 'espaloma',
            "code": "espaloma-0.3.1",
        },
        "hmr_factor": 2.5,
        "safe_naming_prefix": 'z',
        "name": 'WP6'
    }

parameterizer = Parameterize(
    force_field_code = dict_to_work['ff']['code'],
    force_field_type = dict_to_work['ff']['type'], 
    ext_types = ['top', 'gro'],
    hmr_factor = dict_to_work['hmr_factor'],
    overwrite = True,
    safe_naming_prefix = dict_to_work['safe_naming_prefix'],
    out_dir = '.',
)
# Actually you can pass to parameterize Chem.rdchem.Mol, *.inchi, *.smi, *.mol, *.mol2, *.sdf
parameterizer(input_mol = dict_to_work['conf'], mol_resi_name = dict_to_work['name'])

```
